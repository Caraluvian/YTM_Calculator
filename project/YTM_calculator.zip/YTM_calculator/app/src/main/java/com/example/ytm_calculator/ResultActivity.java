package com.example.ytm_calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;
import static java.lang.Float.parseFloat;
import static java.lang.Integer.parseInt;

public class ResultActivity extends AppCompatActivity {

    TextView fv_result,bv_result,coupon_result,maturity_result,ytm_results;
    float face_v,bond_v,coupon_rates,y_of_m,results,coupon;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        fv_result = (TextView) findViewById(R.id.txt_fv);
        bv_result = (TextView) findViewById(R.id.txt_bv);
        coupon_result = (TextView) findViewById(R.id.txt_c);
        maturity_result = (TextView) findViewById(R.id.txt_yofm);
        ytm_results = (TextView) findViewById(R.id.txt_results);

        //Get the data from user input and show them as results
        Intent intent_fv = getIntent();
        fv_result.setText(intent_fv.getStringExtra("fv"));
        Intent intent_bv = getIntent();
        bv_result.setText(intent_bv.getStringExtra("bv"));
        Intent intent_c = getIntent();
        coupon_result.setText(intent_c.getStringExtra("c"));
        Intent intent_yofm = getIntent();
        maturity_result.setText(intent_yofm.getStringExtra("yofm"));

        //Convert user inputs to float and convert year of maturity to int
        face_v = parseFloat(String.valueOf(fv_result.getText()));
        bond_v = parseFloat(String.valueOf(bv_result.getText()));
        coupon_rates = parseFloat(String.valueOf(coupon_result.getText()));
        y_of_m = parseInt(String.valueOf(maturity_result.getText()));

        //Calculate coupon value using coupon rate and face value using formula coupon = (coupon_rates/100) * face_value
        coupon = (coupon_rates/100) * face_v ;
        //Calculate the YTM by formula YTM=(Coupon+(face_value-bond_price)/year_of_maturity)/((face_value+bond_price)/2)
        results = (coupon + (face_v - bond_v) / y_of_m) / ((face_v + bond_v)/2) ;
        //convert the result to percentage
        results = results * 100;
        ytm_results.setText(String.format("%s", results + "%"));
    }
}