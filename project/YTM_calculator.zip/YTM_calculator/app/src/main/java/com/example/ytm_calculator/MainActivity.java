package com.example.ytm_calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    //initialize
    Button button_cal;
    EditText face_value, bond_value, coupon, maturity_year;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button_cal = (Button) findViewById(R.id.btn_cal);
        face_value = (EditText) findViewById(R.id.fv_value);
        bond_value = (EditText) findViewById(R.id.b_value);
        coupon = (EditText) findViewById(R.id.coupon_rates);
        maturity_year = (EditText) findViewById(R.id.years_of_maturity);

        //When click calculate button, jump to result page
        button_cal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, ResultActivity.class);

                //Transfer the input data to the result page
                String fv = face_value.getText().toString().trim();
                intent.putExtra("fv",fv);
                String bv = bond_value.getText().toString().trim();
                intent.putExtra("bv",bv);
                String c = coupon.getText().toString().trim();
                intent.putExtra("c",c);
                String yofm = maturity_year.getText().toString().trim();
                intent.putExtra("yofm",yofm);

                //jump to result page
                startActivity(intent);
            }
        });
    }
}